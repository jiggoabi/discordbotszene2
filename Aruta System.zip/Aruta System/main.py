import discord
import asyncio
import ezcord
import os
import enums
from discord.commands import slash_command, Option
import psutil
import aiohttp
from io import BytesIO
import requests
import json
import datetime

intents = discord.Intents.all()

ezcord.set_log(
    log_format=ezcord.LogFormat.default,
    webhook_url=(
        "https://discord.com/api/webhooks/1151208589122343053/sNxDm6a6Yi-Pf0Tu0-fcONEc1hQ-QhiMEL9SOJdIVO-YRHKTHjrtx_82pDv261n_ixO7"),
    discord_log_level=20
)

bot = ezcord.Bot(intents=intents,
                 error_webhook_url=(
                     "https://discord.com/api/webhooks/1151208589122343053/sNxDm6a6Yi-Pf0Tu0-fcONEc1hQ-QhiMEL9SOJdIVO-YRHKTHjrtx_82pDv261n_ixO7"),
                 )








if __name__ == "__main__":
    bot.load_cogs("cogs")

bot.run("OTU0NzI5NDY2NjMzMDAzMDE4.GztRDc.mAcOg21Y50V-qZODkeIVu_ZArm5bV6O1L-mQx8")