import discord
from discord.ext import commands
from discord.commands import slash_command, Option


class Fortnite(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @slash_command(description="Fortnite")
    async def fortnite(self, ctx,
                       auswahl: Option(str, choices=["für fortnite", "gegen fortnite"], description="Wähle weise", required=True)):

        für = discord.Embed(
            title="Für Fortnite!",
            description=f"{ctx.author.mention} ist für Fortnite",
            color=0x2ECC70
        )
        für.set_image(url="https://cdn.discordapp.com/attachments/1078679085204635769/1078680440564617336/furfortnite.png")

        gegen = discord.Embed(
            title="Gegen Fortnite!",
            description=f"{ctx.author.mention} ist gegen Fortnite!",
            color=0xE74D3C
        )
        gegen.set_image(url="https://cdn.discordapp.com/attachments/1078679085204635769/1078680439801270272/gegenfortnite.png")

        if auswahl == "für fortnite":
            await ctx.respond(embed=für)

        else:
            await ctx.respond(embed=gegen)

def setup(bot):
    bot.add_cog(Fortnite(bot))